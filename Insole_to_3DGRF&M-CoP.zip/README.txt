Segmentation Models Supported:
UNet: UNet, UNet-Ensembled, UNet+ (UNetP), UNet++(UNetPP), MultiResUNet
LinkNet: LinkNet, LinkNet-Ensembled, LinkNet+ (LinkNetP), LinkNet++(LinkNetPP), MultiResLinkNet
TernausNet: TernausNet11, TernausNet16, TernausNet19
AlbuNet: AlbuNet18, AlbuNet34, AlbuNet50, AlbuNet101, AlbuNet152
Feature Pyramid Network (FPN)